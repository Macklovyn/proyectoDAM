class Materia {
  String IDMATERIA;
  String NOMBRE;
  String SEMESTRE;
  String DOCENTE;

  Materia({
    required this.IDMATERIA,
    required this.NOMBRE,
    required this.SEMESTRE,
    required this.DOCENTE,
  });

  Map<String, dynamic> toJSON() {
    return {
      'IDMATERIA': IDMATERIA,
      'NOMBRE': NOMBRE,
      'SEMESTRE': SEMESTRE,
      'DOCENTE': DOCENTE,
    };
  }
}