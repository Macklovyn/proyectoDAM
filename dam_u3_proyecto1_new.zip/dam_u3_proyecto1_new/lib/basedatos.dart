import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:dam_u3_proyecto1_new/Materia.dart';
import 'package:dam_u3_proyecto1_new/Tarea.dart';

class DB {
  static Future<Database> _openDB() async {
    return openDatabase(
      join(await getDatabasesPath(), "U3practica.db"),
      onCreate: (db, version) async {
        await db.execute(
            "CREATE TABLE MATERIA(IDMATERIA TEXT PRIMARY KEY, NOMBRE TEXT, SEMESTRE TEXT, DOCENTE TEXT)");
        await db.execute(
            "CREATE TABLE TAREA(IDTAREA INTEGER PRIMARY KEY, IDMATERIA TEXT, F_ENTREGA TEXT, DESCRIPCION TEXT, FOREIGN KEY (IDMATERIA) REFERENCES MATERIA(IDMATERIA))");
      },
      version: 1,
    );
  }
  static Future<int> insertMateria(Materia m) async {
    Database db = await _openDB();
    return db.insert("MATERIA", m.toJSON(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<void> insertTarea(Tarea t) async {
    Database db = await _openDB();
    await db.insert("TAREA", t.toJSON());
  }

  static Future<List<Materia>> mostrarTodasMaterias() async {
    Database db = await _openDB();
    List<Map<String, dynamic>> resultado = await db.query("MATERIA");
    return List.generate(resultado.length, (index) {
      return Materia(
        IDMATERIA: resultado[index]['IDMATERIA'],
        NOMBRE: resultado[index]['NOMBRE'],
        SEMESTRE: resultado[index]['SEMESTRE'],
        DOCENTE: resultado[index]['DOCENTE'],
      );
    });
  }

  static Future<List<Tarea>> mostrarTodasTareas() async {
    Database db = await _openDB();
    List<Map<String, dynamic>> resultado = await db.query("TAREA");

    return List.generate(resultado.length, (index) {
      final idTarea = resultado[index]['IDTAREA'] as int;
      final idMateria = resultado[index]['IDMATERIA'] as String;
      final fEntrega = resultado[index]['F_ENTREGA'] as String;
      final descripcion = resultado[index]['DESCRIPCION'] as String;

      return Tarea(
        IDTAREA: idTarea,
        IDMATERIA: idMateria,
        F_ENTREGA: fEntrega,
        DESCRIPCION: descripcion,
      );
    });
  }

  static Future<int> eliminarTarea(int idTarea) async {
    Database db = await _openDB();
    return db.delete("TAREA", where: "IDTAREA = ?", whereArgs: [idTarea]);
  }

  static Future<int> eliminarMateria(String idMateria) async {
    Database db = await _openDB();
    return db.delete("MATERIA", where: "IDMATERIA = ?", whereArgs: [idMateria]);
  }

  static Future<int> actualizarTarea(Tarea tarea) async {
    Database db = await _openDB();
    return db.update("TAREA", tarea.toJSON(),
        where: "IDTAREA = ?", whereArgs: [tarea.IDTAREA]);
  }

  static Future<int> actualizarMateria(Materia materia) async {
    Database db = await _openDB();
    return db.update("MATERIA", materia.toJSON(),
        where: "IDMATERIA = ?", whereArgs: [materia.IDMATERIA]);
  }

}