import 'package:flutter/material.dart';
import 'Tarea.dart';
import 'Materia.dart';
import 'basedatos.dart';


class App33 extends StatefulWidget {
  const App33({super.key});

  @override
  State<App33> createState() => _App33State();
}

class _App33State extends State<App33> {int _index = 0;
String titulo = "Proyecto 1";
final IDMATERIA = TextEditingController();
final NOMBRE = TextEditingController();
final SEMESTRE = TextEditingController();
final DOCENTE = TextEditingController();

final IDTAREA = TextEditingController();
final F_ENTREGA = TextEditingController();
final DESCRIPCION = TextEditingController();
List<Materia> materiasAgregadas = [];
List<Tarea> tareasAgregadas = [];

@override
void initState() {
  super.initState();

}



@override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text("$titulo"),
      centerTitle: true,
    ),
    body: dinamico(),
    bottomNavigationBar: BottomNavigationBar(
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.list_alt), label: "Tarea"),
        BottomNavigationBarItem(icon: Icon(Icons.add), label: "Materia"),
        BottomNavigationBarItem(icon: Icon(Icons.access_alarm), label: "HOY"),
      ],
      currentIndex: _index,
      onTap: (indice) {
        setState(() {
          _index = indice;
        });
      },
    ),
  );
}

Widget dinamico() {
  switch (_index) {
    case 0:
      return PaginaTareas();
    case 1:
      return PaginaMaterias();
    case 2:
      return PaginaHoy();
    default:
      return Center(child: Text("Página no encontrada"));
  }
}

Widget PaginaTareas() {
  return Scaffold(
    floatingActionButton: FloatingActionButton(
      onPressed: () {
        showModalBottomSheet(
          context: context,
          builder: (context) {
            return Container(
              padding: EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text("Agregar Tarea", style: TextStyle(fontSize: 20)),
                  TextFormField(
                    controller: IDMATERIA,
                    decoration: InputDecoration(labelText: "Materia"),
                  ),
                  TextFormField(
                    controller: F_ENTREGA,
                    decoration: InputDecoration(labelText: "Fecha de Entrega"),
                  ),
                  TextFormField(
                    controller: DESCRIPCION,
                    decoration: InputDecoration(labelText: "Descripción"),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      var temporal = Tarea(
                          IDMATERIA: IDMATERIA.text,
                          F_ENTREGA: F_ENTREGA.text,
                          DESCRIPCION: DESCRIPCION.text);
                      DB.insertTarea(temporal).then((value) {
                        setState(() {
                          // Actualiza la lista de tareas.
                          IDMATERIA.text = "";
                          F_ENTREGA.text = "";
                          DESCRIPCION.text = "";
                        });
                      });
                    },
                    child: Text("Agregar Tarea"),
                  ),
                ],
              ),
            );
          },
        );
      },
      child: Icon(Icons.add),
    ),
    floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
  );
}

Widget PaginaMaterias() {
  return Center();
}

Widget PaginaHoy() {
  return Center(child: Text("Página 'HOY' en construcción"));
}
}