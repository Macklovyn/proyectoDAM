class Tarea {
  int? IDTAREA;
  String IDMATERIA;
  String F_ENTREGA;
  String DESCRIPCION;

  Tarea({
    this.IDTAREA,
    required this.IDMATERIA,
    required this.F_ENTREGA,
    required this.DESCRIPCION,
  });

  Map<String, dynamic> toJSON() {
    return {
      'IDTAREA': IDTAREA,
      'IDMATERIA': IDMATERIA,
      'F_ENTREGA': F_ENTREGA,
      'DESCRIPCION': DESCRIPCION,
    };
  }
}
