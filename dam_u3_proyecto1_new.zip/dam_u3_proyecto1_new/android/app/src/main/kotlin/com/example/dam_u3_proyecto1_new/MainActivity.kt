package com.example.dam_u3_proyecto1_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
